import { NavItem } from './nav-item/nav-item';

export const driveNavItems: NavItem[] = [
  {
    navCap: 'My Drive',
  },
];
export const InteractionNavItems: NavItem[] = [
  {
    navCap: 'My Interaction',
  },
];
