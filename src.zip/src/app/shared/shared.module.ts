import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {  TreeStructureComponent } from './tree/tree.component';
import { TreeModule } from '@circlon/angular-tree-component';
import { DialogBoxComponent } from './dialog/dialog.component';
import { MaterialModule } from '../material.module';



@NgModule({
  declarations: [
    
  
    
  ],
  imports: [
    CommonModule,
    MaterialModule
  ]
})
export class SharedModule { }
