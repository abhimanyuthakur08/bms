import { Component, ViewChild } from '@angular/core';
import { ITreeOptions, TreeNode ,TreeComponent} from '@circlon/angular-tree-component';
import { DialogBoxComponent } from '../dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss']
})
export class TreeStructureComponent {
  @ViewChild('tree') tree: TreeComponent;

  nodes:any = [
  ];

  constructor(public dialog: MatDialog){}

  options: ITreeOptions = {
    displayField: 'name',
    useVirtualScroll: true,
    nodeHeight: 25,
    allowDrag: true,
    allowDrop: true
  };

  selectedNode:any;

  onActivateNode(event: any) {
    this.selectedNode = event.node.data;
    // Do stuff with selected node
  }

  copyNode(node: any, tree:any) {
    const parentNode = node.realParent ? node.realParent : node.treeModel.virtualRoot;
    const copyNode = JSON.stringify(node.data);
    const newNode = JSON.parse(copyNode);
    this.deleteIds(newNode);
    parentNode.data.children.push(newNode);
    tree.treeModel.update();
  }

  deleteIds(node: TreeNode) {
    node.id = null;
    if (node.children) {
      node.children.forEach(child => this.deleteIds(child));
    }
  }

  addNode(node: any, name: string) {
    if(node == null){
      const newNode = {name: name};
      this.nodes.push(newNode)
      this.tree.treeModel.update();
    }
    else{
      const newNode = {name: name};
      if (!node.data.children) {
        node.data.children = [];
      }
      node.data.children.push(newNode);
      this.tree.treeModel.update();
      const someNode = this.tree.treeModel.getNodeById(node.id);
    someNode.expand()
    }
   

    ;
  }

  deleteNode(node:any, tree:any) {
    const parentNode = node.realParent ? node.realParent : node.treeModel.virtualRoot;
    parentNode.data.children = parentNode.data.children.filter((child:any) => {
      return child !== node.data;
    });
    tree.treeModel.update();
    if (node && node.parent && node.parent.data && node.parent.data.children.length === 0) {
      node.parent.data.hasChildren = false;
    }

    if (this.selectedNode?.id === node.data.id) {
      this.selectedNode = null;
    }
  }

  

  openDialog(node: any): void {
    const dialogRef = this.dialog.open(DialogBoxComponent, {
      data: {},
      width:'500px',
      height:'200px'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.addNode(node, result)
    });
  }
}
