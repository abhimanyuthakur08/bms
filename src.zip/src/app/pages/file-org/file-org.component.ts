import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-org',
  templateUrl: './file-org.component.html',
  styleUrls: ['./file-org.component.scss']
})
export class FileOrgComponent  implements OnInit {
  menuSelected: string ='version';
  selectedImage: any;
  isFullScreen: boolean = false;
  productcards: any = [
    {
      id: 1,
      imgSrc: '/assets/images/products/s4.jpg',
      title: 'Boat Headphone',
      price: '285',
      rprice: '375',
    },
    {
      id: 2,
      imgSrc: '/assets/images/products/s5.jpg',
      title: 'MacBook Air Pro',
      price: '285',
      rprice: '375',
    },
    {
      id: 3,
      imgSrc: '/assets/images/products/s7.jpg',
      title: 'Red Valvet Dress',
      price: '285',
      rprice: '375',
    },
    {
      id: 4,
      imgSrc: '/assets/images/products/s11.jpg',
      title: 'Cute Soft Teddybear',
      price: '285',
      rprice: '375',
    },
  ];
  subMenuClick(menu:string){
    this.menuSelected= menu;
  }

  ngOnInit() {
    this.selectedImage=this.productcards[0];
  }

  versionSelected(index: any){
    this.selectedImage = this.productcards[index];
  }

  fullScreen(value:boolean){
    this.isFullScreen = value;
  }

  onChange(event:any){
    this.versionSelected(event.target.value);
  }
}
