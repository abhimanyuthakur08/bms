import { Routes } from '@angular/router';
import { AppDashboardComponent } from './dashboard/dashboard.component';
import { DriveComponent } from './drive/drive.component';
import { FileOrgComponent } from './file-org/file-org.component';

export const PagesRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'drive',
        component: DriveComponent,
      },
      {
        path: 'file',
        component: FileOrgComponent,
      },
    ],
    
  }
];
