import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FileOrgComponent } from './file-org.component';

describe('FileOrgComponent', () => {
  let component: FileOrgComponent;
  let fixture: ComponentFixture<FileOrgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FileOrgComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FileOrgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
